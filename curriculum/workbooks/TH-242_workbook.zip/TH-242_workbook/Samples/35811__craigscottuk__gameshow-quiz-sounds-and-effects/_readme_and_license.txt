Sound pack downloaded from Freesound
----------------------------------------

"Gameshow Quiz Sounds and Effects"

This pack of sounds contains sounds by the following user:
 - craigscottuk ( https://freesound.org/people/craigscottuk/ )

You can find this pack online at: https://freesound.org/people/craigscottuk/packs/35811/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 644963__craigscottuk__quiz-gameshow-correct-ping-14.mp3
    * url: https://freesound.org/s/644963/
    * license: Creative Commons 0
  * 644962__craigscottuk__quiz-gameshow-correct-ping-15.mp3
    * url: https://freesound.org/s/644962/
    * license: Creative Commons 0
  * 644961__craigscottuk__quiz-gameshow-correct-ping-10.mp3
    * url: https://freesound.org/s/644961/
    * license: Creative Commons 0
  * 644960__craigscottuk__quiz-gameshow-correct-ping-11.mp3
    * url: https://freesound.org/s/644960/
    * license: Creative Commons 0
  * 644959__craigscottuk__quiz-gameshow-correct-ping-12.mp3
    * url: https://freesound.org/s/644959/
    * license: Creative Commons 0
  * 644958__craigscottuk__quiz-gameshow-correct-ping-13.mp3
    * url: https://freesound.org/s/644958/
    * license: Creative Commons 0
  * 644957__craigscottuk__quiz-gameshow-correct-ping-06.mp3
    * url: https://freesound.org/s/644957/
    * license: Creative Commons 0
  * 644956__craigscottuk__quiz-gameshow-correct-ping-07.mp3
    * url: https://freesound.org/s/644956/
    * license: Creative Commons 0
  * 644955__craigscottuk__quiz-gameshow-correct-ping-08.mp3
    * url: https://freesound.org/s/644955/
    * license: Creative Commons 0
  * 644954__craigscottuk__quiz-gameshow-correct-ping-09.mp3
    * url: https://freesound.org/s/644954/
    * license: Creative Commons 0
  * 644953__craigscottuk__quiz-gameshow-correct-ring-01.mp3
    * url: https://freesound.org/s/644953/
    * license: Creative Commons 0
  * 644952__craigscottuk__quiz-gameshow-correct-ping-16.mp3
    * url: https://freesound.org/s/644952/
    * license: Creative Commons 0
  * 644951__craigscottuk__quiz-gameshow-correct-ping-04.mp3
    * url: https://freesound.org/s/644951/
    * license: Creative Commons 0
  * 644950__craigscottuk__quiz-gameshow-correct-ping-05.mp3
    * url: https://freesound.org/s/644950/
    * license: Creative Commons 0
  * 644949__craigscottuk__quiz-gameshow-correct-ding-04.mp3
    * url: https://freesound.org/s/644949/
    * license: Creative Commons 0
  * 644948__craigscottuk__quiz-gameshow-correct-ping-01.mp3
    * url: https://freesound.org/s/644948/
    * license: Creative Commons 0
  * 644947__craigscottuk__quiz-gameshow-correct-ping-02.mp3
    * url: https://freesound.org/s/644947/
    * license: Creative Commons 0
  * 644946__craigscottuk__quiz-gameshow-correct-ping-03.mp3
    * url: https://freesound.org/s/644946/
    * license: Creative Commons 0
  * 644945__craigscottuk__quiz-gameshow-correct-ding-01.mp3
    * url: https://freesound.org/s/644945/
    * license: Creative Commons 0
  * 644944__craigscottuk__quiz-gameshow-correct-ding-02.mp3
    * url: https://freesound.org/s/644944/
    * license: Creative Commons 0
  * 644943__craigscottuk__quiz-gameshow-correct-ding-03.mp3
    * url: https://freesound.org/s/644943/
    * license: Creative Commons 0
  * 644942__craigscottuk__quiz-gameshow-correct-ding-04.mp3
    * url: https://freesound.org/s/644942/
    * license: Creative Commons 0


