Sound pack downloaded from Freesound
----------------------------------------

"Sound Effects"

This pack of sounds contains sounds by the following user:
 - UNIVERSFIELD ( https://freesound.org/people/UNIVERSFIELD/ )

You can find this pack online at: https://freesound.org/people/UNIVERSFIELD/packs/40324/


Pack description
----------------

General collection of sound effects.


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution 4.0: https://creativecommons.org/licenses/by/4.0/


Sounds in this pack
-------------------

  * 750243__universfield__creepy-pig-roar.mp3
    * url: https://freesound.org/s/750243/
    * license: Attribution 4.0
  * 750242__universfield__creepy-horror-sound.mp3
    * url: https://freesound.org/s/750242/
    * license: Attribution 4.0
  * 750241__universfield__crackling-fire.mp3
    * url: https://freesound.org/s/750241/
    * license: Attribution 4.0
  * 750240__universfield__coin-drop.mp3
    * url: https://freesound.org/s/750240/
    * license: Attribution 4.0
  * 750239__universfield__clumsy-moment-sound.mp3
    * url: https://freesound.org/s/750239/
    * license: Attribution 4.0
  * 750238__universfield__cartoon-scream.mp3
    * url: https://freesound.org/s/750238/
    * license: Attribution 4.0
  * 750237__universfield__bubbles-bursting.mp3
    * url: https://freesound.org/s/750237/
    * license: Attribution 4.0
  * 750236__universfield__bubble-popping.mp3
    * url: https://freesound.org/s/750236/
    * license: Attribution 4.0
  * 750235__universfield__boiling-liquid.mp3
    * url: https://freesound.org/s/750235/
    * license: Attribution 4.0
  * 750234__universfield__blaster-shot.mp3
    * url: https://freesound.org/s/750234/
    * license: Attribution 4.0
  * 736267__universfield__new-notification-7.mp3
    * url: https://freesound.org/s/736267/
    * license: Attribution 4.0
  * 734446__universfield__error-10.mp3
    * url: https://freesound.org/s/734446/
    * license: Attribution 4.0
  * 734445__universfield__new-notification-6.mp3
    * url: https://freesound.org/s/734445/
    * license: Attribution 4.0
  * 734444__universfield__error-9.mp3
    * url: https://freesound.org/s/734444/
    * license: Attribution 4.0
  * 734443__universfield__system-notification-4.mp3
    * url: https://freesound.org/s/734443/
    * license: Attribution 4.0
  * 734442__universfield__error-8.mp3
    * url: https://freesound.org/s/734442/
    * license: Attribution 4.0
  * 730122__universfield__system-notification.mp3
    * url: https://freesound.org/s/730122/
    * license: Attribution 4.0
  * 730120__universfield__error-5.mp3
    * url: https://freesound.org/s/730120/
    * license: Attribution 4.0
  * 730119__universfield__error-4.mp3
    * url: https://freesound.org/s/730119/
    * license: Attribution 4.0
  * 724924__universfield__high-speed.mp3
    * url: https://freesound.org/s/724924/
    * license: Attribution 4.0
  * 724923__universfield__high-speed-2.mp3
    * url: https://freesound.org/s/724923/
    * license: Attribution 4.0
  * 721676__universfield__a-splash-of-water.mp3
    * url: https://freesound.org/s/721676/
    * license: Attribution 4.0


